# سُعرات — تطبيق تتبّع السعرات للمطبخ العربي

واجهة عربية (RTL) + Supabase (مصادقة، قاعدة بيانات، RLS) + Gemini عبر Edge Function (المفتاح لا يغادر الخادم).

## البنية
- `supabase/migrations/…init.sql` — الجداول (profiles, foods, meal_logs, ai_usage) + سياسات RLS + ٢٥ طبقًا عربيًا (قيم تقريبية `verified=false`).
- `supabase/functions/analyze-meal/` — `handler.js` (المصادقة، التحقق، حد ٣٠ طلبًا/ساعة)، `gemini.js`، `nutrition.js` (تنقية مخرجات النموذج)، `index.ts` (ربط Deno).
- `web/` — واجهة ثابتة بلا خطوة بناء: `calc.js` (BMR/TDEE، بحث عربي)، `app.js`.
- `tests/` — اختبارات `node:test` (بلا مكتبات خارجية).

## التشغيل (بعد موافقتك على إنشاء/اختيار مشروع Supabase)
```bash
npm test                                   # ٢٥ اختبارًا محليًا
supabase link --project-ref <REF>
supabase db push                           # يطبّق الـ migration
supabase secrets set GEMINI_API_KEY=... ALLOWED_ORIGIN=https://your-domain   # لا تضع المفتاح في أي ملف يُرفع
supabase functions deploy analyze-meal     # لا تستخدم --no-verify-jwt
cp web/config.example.js web/config.js     # ضع SUPABASE_URL و anon key فقط
npx serve web                              # أو أي استضافة ثابتة
```
## قيود معروفة
- قيم الأطعمة تقريبية وتحتاج مراجعة مختص تغذية قبل الاعتماد عليها طبيًا.
- ليست أداة طبية؛ يوجد حد أدنى آمن للهدف اليومي (١٢٠٠/١٥٠٠).
- حد الاستخدام غير ذرّي (طلبان متزامنان قد يتجاوزان الحد بقليل).
- الواجهة تحمّل supabase-js من CDN مثبّت الإصدار بلا SRI؛ للإنتاج يُفضّل تجميعه محليًا وإضافة CSP.
