import { RESPONSE_SCHEMA, SYSTEM_PROMPT } from "./nutrition.js";

// The API key goes in a header, never in the URL (URLs end up in logs).
export async function callGemini(description, { apiKey, model = "gemini-2.5-flash", fetchImpl = fetch, timeoutMs = 20000 }) {
  if (!apiKey) throw new Error("missing_api_key");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const res = await fetchImpl(url, {
    method: "POST",
    headers: { "content-type": "application/json", "x-goog-api-key": apiKey },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: [{ role: "user", parts: [{ text: description }] }],
      generationConfig: { responseMimeType: "application/json", responseSchema: RESPONSE_SCHEMA, temperature: 0.2 },
    }),
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!res.ok) throw new Error(`gemini_http_${res.status}`);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (typeof text !== "string") throw new Error("gemini_empty");
  return JSON.parse(text);
}
