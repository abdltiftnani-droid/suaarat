import { sanitizeAiItems } from "./nutrition.js";

export const LIMITS = { minChars: 2, maxChars: 500, perHour: 30 };

// deps: { getUserId(token), usageCount(token, sinceISO), recordUsage(token, userId), analyze(description) }
export function createHandler(deps, { allowedOrigin = "*", limits = LIMITS, now = () => Date.now() } = {}) {
  const cors = {
    "access-control-allow-origin": allowedOrigin,
    "access-control-allow-headers": "authorization, apikey, content-type, x-client-info",
    "access-control-allow-methods": "POST, OPTIONS",
  };
  const json = (status, body) =>
    new Response(JSON.stringify(body), { status, headers: { ...cors, "content-type": "application/json" } });

  return async function handle(req) {
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (req.method !== "POST") return json(405, { error: "method_not_allowed" });

    const auth = req.headers.get("authorization") || "";
    const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
    if (!token) return json(401, { error: "unauthorized" });
    const userId = await deps.getUserId(token).catch(() => null);
    if (!userId) return json(401, { error: "unauthorized" });

    let body;
    try { body = await req.json(); } catch { return json(400, { error: "invalid_json" }); }
    const description = typeof body?.description === "string" ? body.description.trim() : "";
    if (description.length < limits.minChars || description.length > limits.maxChars) {
      return json(400, { error: "invalid_description", maxChars: limits.maxChars });
    }

    const since = new Date(now() - 3600_000).toISOString();
    const used = await deps.usageCount(token, since);
    if (used >= limits.perHour) return json(429, { error: "rate_limited" });
    await deps.recordUsage(token, userId); // count the attempt before spending money on Gemini

    let raw;
    try { raw = await deps.analyze(description); }
    catch (e) { console.error("analyze failed:", e?.message); return json(502, { error: "analysis_failed" }); }

    const items = sanitizeAiItems(raw);
    if (items.length === 0) return json(422, { error: "no_items" });
    return json(200, { items });
  };
}
