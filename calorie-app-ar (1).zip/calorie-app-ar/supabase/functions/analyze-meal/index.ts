// Supabase Edge Function (Deno). JWT verification stays ON (default) — do not deploy with --no-verify-jwt.
// Secrets (set with `supabase secrets set`): GEMINI_API_KEY, optional GEMINI_MODEL, ALLOWED_ORIGIN.
import { createClient } from "jsr:@supabase/supabase-js@2";
import { createHandler } from "./handler.js";
import { callGemini } from "./gemini.js";

const url = Deno.env.get("SUPABASE_URL")!;
const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
const userClient = (token: string) =>
  createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false } });

const handler = createHandler(
  {
    getUserId: async (token: string) => (await userClient(token).auth.getUser(token)).data.user?.id ?? null,
    usageCount: async (token: string, since: string) => {
      const { count, error } = await userClient(token)
        .from("ai_usage").select("id", { count: "exact", head: true }).gte("created_at", since);
      if (error) throw error;
      return count ?? 0;
    },
    recordUsage: async (token: string, userId: string) => {
      const { error } = await userClient(token).from("ai_usage").insert({ user_id: userId });
      if (error) throw error;
    },
    analyze: (description: string) =>
      callGemini(description, {
        apiKey: Deno.env.get("GEMINI_API_KEY")!,
        model: Deno.env.get("GEMINI_MODEL") ?? "gemini-2.5-flash",
      }),
  },
  { allowedOrigin: Deno.env.get("ALLOWED_ORIGIN") ?? "*" },
);

Deno.serve(handler);
