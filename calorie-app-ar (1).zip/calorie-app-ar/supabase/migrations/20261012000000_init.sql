-- Arab calorie tracker: schema + RLS + seed foods
create table public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  sex text not null check (sex in ('male','female')),
  birth_year int not null check (birth_year between 1920 and 2020),
  height_cm numeric not null check (height_cm between 100 and 250),
  weight_kg numeric not null check (weight_kg between 25 and 350),
  activity text not null check (activity in ('sedentary','light','moderate','active')),
  goal text not null check (goal in ('lose','maintain','gain')),
  updated_at timestamptz not null default now()
);

create table public.foods (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null unique,
  name_en text,
  category text not null,
  kcal_100g numeric not null check (kcal_100g >= 0 and kcal_100g <= 900),
  protein_100g numeric not null check (protein_100g >= 0),
  carbs_100g numeric not null check (carbs_100g >= 0),
  fat_100g numeric not null check (fat_100g >= 0),
  default_serving_g numeric not null check (default_serving_g > 0),
  serving_label_ar text,
  verified boolean not null default false  -- false = approximate, pending nutritionist review
);

create table public.meal_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  eaten_on date not null default current_date,
  meal_type text not null check (meal_type in ('breakfast','lunch','dinner','snack')),
  name_ar text not null check (char_length(name_ar) between 1 and 120),
  grams numeric not null check (grams > 0 and grams <= 5000),
  kcal numeric not null check (kcal >= 0 and kcal <= 5000),
  protein_g numeric not null default 0 check (protein_g between 0 and 500),
  carbs_g numeric not null default 0 check (carbs_g between 0 and 1000),
  fat_g numeric not null default 0 check (fat_g between 0 and 500),
  source text not null check (source in ('db','ai','manual')),
  food_id uuid references public.foods(id) on delete set null,
  created_at timestamptz not null default now()
);
create index meal_logs_user_day_idx on public.meal_logs (user_id, eaten_on);

create table public.ai_usage (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create index ai_usage_user_time_idx on public.ai_usage (user_id, created_at desc);

alter table public.profiles  enable row level security;
alter table public.foods     enable row level security;
alter table public.meal_logs enable row level security;
alter table public.ai_usage  enable row level security;

create policy "profiles_own" on public.profiles for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "foods_read" on public.foods for select to authenticated using (true);
create policy "meals_own" on public.meal_logs for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "usage_select_own" on public.ai_usage for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "usage_insert_own" on public.ai_usage for insert to authenticated
  with check ((select auth.uid()) = user_id);

-- Approximate values per 100 g (verified=false). Review with a nutritionist before relying on them.
insert into public.foods (name_ar,name_en,category,kcal_100g,protein_100g,carbs_100g,fat_100g,default_serving_g,serving_label_ar) values
('كبسة دجاج','Chicken kabsa','أطباق رئيسية',165,9,21,5,350,'طبق'),
('كبسة لحم','Lamb kabsa','أطباق رئيسية',190,10,21,7,350,'طبق'),
('مندي لحم','Lamb mandi','أطباق رئيسية',210,11,22,8,350,'طبق'),
('مقلوبة','Maqluba','أطباق رئيسية',175,8,22,6,350,'طبق'),
('منسف','Mansaf','أطباق رئيسية',200,11,20,9,350,'طبق'),
('هريس','Harees','أطباق رئيسية',180,10,20,6,250,'طبق'),
('كشري','Koshari','أطباق رئيسية',150,5,27,2.5,350,'طبق'),
('ملوخية مطبوخة','Molokhia stew','أطباق رئيسية',70,5,6,3,250,'طبق'),
('شاورما دجاج (بدون خبز)','Chicken shawarma, no bread','مشويات',190,20,3,11,150,'حصة'),
('كباب مشوي','Grilled kebab','مشويات',250,18,3,18,120,'حصة'),
('رز أبيض مطبوخ','Cooked white rice','نشويات',130,2.7,28,0.3,200,'كوب كبير'),
('خبز عربي','Arabic pita bread','نشويات',275,9,56,1.2,60,'رغيف'),
('فلافل','Falafel','مقبلات',333,13,32,18,60,'٣ حبات'),
('حمص (غموس)','Hummus dip','مقبلات',166,8,14,10,80,'٥ ملاعق'),
('فول مدمس','Ful medames','مقبلات',120,7,17,3,200,'طبق'),
('بابا غنوج','Baba ghanoush','مقبلات',130,2,8,10,80,'٥ ملاعق'),
('لبنة','Labneh','ألبان',160,6,4,14,50,'٣ ملاعق'),
('تبولة','Tabbouleh','سلطات',100,2,11,6,150,'طبق صغير'),
('فتوش','Fattoush','سلطات',80,2,9,4.5,150,'طبق صغير'),
('محشي ورق عنب','Stuffed grape leaves','مقبلات',160,3,22,7,100,'٤ قطع'),
('سمبوسة','Samosa/sambousek','معجنات',300,8,28,17,50,'قطعتان'),
('كنافة','Kunafa','حلويات',350,6,45,17,100,'قطعة'),
('لقيمات','Luqaimat','حلويات',380,5,50,18,60,'٥ حبات'),
('تمر','Dates','فواكه',282,2.5,75,0.4,30,'٣ حبات'),
('قهوة عربية','Arabic coffee','مشروبات',2,0.1,0.3,0,60,'فنجانان')
on conflict (name_ar) do nothing;
