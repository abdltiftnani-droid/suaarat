// Copy to config.js. The anon key is public by design (protected by RLS). NEVER put the service_role key or Gemini key here.
export const CONFIG = { SUPABASE_URL: "https://YOUR-PROJECT.supabase.co", SUPABASE_ANON_KEY: "YOUR-ANON-KEY" };
