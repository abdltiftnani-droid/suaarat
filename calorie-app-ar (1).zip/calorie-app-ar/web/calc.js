// Pure logic (no DOM) so it can be unit-tested in Node.
export const ACTIVITY = { sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725 };
const MIN_KCAL = { male: 1500, female: 1200 }; // safety floor: never suggest a target below this

export function bmr({ sex, weight_kg, height_cm, age }) {
  return 10 * weight_kg + 6.25 * height_cm - 5 * age + (sex === "male" ? 5 : -161); // Mifflin–St Jeor
}

export function dailyTarget(profile, year = new Date().getFullYear()) {
  const age = year - profile.birth_year;
  const base = bmr({ sex: profile.sex, weight_kg: profile.weight_kg, height_cm: profile.height_cm, age });
  const tdee = base * (ACTIVITY[profile.activity] ?? 1.2);
  const adj = profile.goal === "lose" ? 0.85 : profile.goal === "gain" ? 1.1 : 1;
  const raw = tdee * adj;
  const floor = MIN_KCAL[profile.sex] ?? 1500;
  return { bmr: Math.round(base), tdee: Math.round(tdee), target: Math.round(Math.max(raw, floor)), floorApplied: raw < floor };
}

const r1 = (n) => Math.round(n * 10) / 10;
export function scaleNutrition(food, grams) {
  const k = grams / 100;
  return {
    kcal: Math.round(food.kcal_100g * k),
    protein_g: r1(food.protein_100g * k),
    carbs_g: r1(food.carbs_100g * k),
    fat_g: r1(food.fat_100g * k),
  };
}

export function sumTotals(rows) {
  return rows.reduce(
    (t, r) => ({ kcal: t.kcal + Number(r.kcal), protein_g: r1(t.protein_g + Number(r.protein_g)), carbs_g: r1(t.carbs_g + Number(r.carbs_g)), fat_g: r1(t.fat_g + Number(r.fat_g)) }),
    { kcal: 0, protein_g: 0, carbs_g: 0, fat_g: 0 },
  );
}

// Arabic-Indic (٠-٩) and Persian (۰-۹) digits -> ASCII, Arabic decimal/comma -> '.'
export function parseNumber(s) {
  const t = String(s ?? "").trim()
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٫,،]/g, ".");
  return /^\d+(\.\d+)?$/.test(t) ? Number(t) : NaN;
}

// Makes Arabic search forgiving: strips diacritics/tatweel, unifies alef, ya, ta marbuta.
export function normalizeArabic(s) {
  return String(s ?? "").toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه")
    .replace(/\s+/g, " ").trim();
}

export function searchFoods(foods, query, limit = 8) {
  const q = normalizeArabic(query);
  if (!q) return [];
  return foods.filter((f) => normalizeArabic(f.name_ar).includes(q) || (f.name_en ?? "").toLowerCase().includes(q)).slice(0, limit);
}
