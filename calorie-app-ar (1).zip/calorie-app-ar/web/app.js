import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm";
import { dailyTarget, scaleNutrition, sumTotals, parseNumber, searchFoods } from "./calc.js";

const root = document.getElementById("app");
// Safe DOM builder: text is always set via textContent/createTextNode, never innerHTML.
const h = (tag, props = {}, ...kids) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k.startsWith("on")) n.addEventListener(k.slice(2), v); else if (k === "class") n.className = v; else n.setAttribute(k, v);
  }
  for (const c of kids.flat()) if (c != null) n.append(c.nodeType ? c : document.createTextNode(String(c)));
  return n;
};
const MEALS = { breakfast: "الفطور", lunch: "الغداء", dinner: "العشاء", snack: "وجبة خفيفة" };
const localDate = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };

let sb, session, profile, foods = [], logs = [], notice = "", tab = "today";

async function boot() {
  let CONFIG;
  try { ({ CONFIG } = await import("./config.js")); }
  catch { root.replaceChildren(h("p", { class: "err" }, "ملف web/config.js غير موجود. انسخ config.example.js إلى config.js وضع رابط مشروع Supabase والمفتاح العام (anon).")); return; }
  sb = createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY);
  sb.auth.onAuthStateChange((_e, s) => { session = s; load(); });
  ({ data: { session } } = await sb.auth.getSession());
  await load();
}

async function load() {
  if (!session) { profile = null; return render(); }
  const [p, f, l] = await Promise.all([
    sb.from("profiles").select("*").maybeSingle(),
    foods.length ? { data: foods } : sb.from("foods").select("*").order("category").order("name_ar"),
    sb.from("meal_logs").select("*").eq("eaten_on", localDate()).order("created_at"),
  ]);
  profile = p.data; foods = f.data ?? []; logs = l.data ?? [];
  if (p.error || l.error) notice = "تعذّر تحميل البيانات. حاول مرة أخرى.";
  render();
}

const say = (m) => { notice = m; render(); };

function authView() {
  const email = h("input", { type: "email", placeholder: "البريد الإلكتروني", autocomplete: "email", dir: "ltr" });
  const pass = h("input", { type: "password", placeholder: "كلمة المرور (٨ أحرف على الأقل)", autocomplete: "current-password", dir: "ltr" });
  const go = (signUp) => async () => {
    const creds = { email: email.value.trim(), password: pass.value };
    const { error } = signUp ? await sb.auth.signUp(creds) : await sb.auth.signInWithPassword(creds);
    say(error ? "تعذّر الدخول: تحقق من البيانات." : signUp ? "تم إنشاء الحساب. إن طُلب منك تأكيد البريد فتحقق من صندوق الوارد." : "");
  };
  return h("div", { class: "card" }, h("h2", {}, "مرحبًا بك في سُعرات"),
    h("p", { class: "mut" }, "تتبّع سعراتك مع أطباقنا: كبسة، مندي، منسف، كشري، وغيرها."),
    email, pass, h("button", { onclick: go(false) }, "دخول"), h("button", { class: "sec", onclick: go(true) }, "إنشاء حساب"));
}

function profileView() {
  const f = (name, el) => { el.name = name; return el; };
  const sel = (name, opts, val) => { const s = f(name, h("select", {}, Object.entries(opts).map(([v, t]) => h("option", { value: v }, t)))); if (val) s.value = val; return s; };
  const p = profile ?? {};
  const els = {
    sex: sel("sex", { male: "ذكر", female: "أنثى" }, p.sex),
    birth_year: f("birth_year", h("input", { inputmode: "numeric", placeholder: "سنة الميلاد (مثال ١٩٩٠)", value: p.birth_year ?? "" })),
    height_cm: f("height_cm", h("input", { inputmode: "decimal", placeholder: "الطول بالسنتيمتر", value: p.height_cm ?? "" })),
    weight_kg: f("weight_kg", h("input", { inputmode: "decimal", placeholder: "الوزن بالكيلوغرام", value: p.weight_kg ?? "" })),
    activity: sel("activity", { sedentary: "قليل الحركة", light: "نشاط خفيف", moderate: "نشاط متوسط", active: "نشاط عالٍ" }, p.activity),
    goal: sel("goal", { lose: "إنقاص الوزن", maintain: "الحفاظ على الوزن", gain: "زيادة الوزن" }, p.goal),
  };
  const save = async () => {
    const row = { sex: els.sex.value, activity: els.activity.value, goal: els.goal.value,
      birth_year: parseNumber(els.birth_year.value), height_cm: parseNumber(els.height_cm.value), weight_kg: parseNumber(els.weight_kg.value) };
    if (![row.birth_year, row.height_cm, row.weight_kg].every(Number.isFinite)) return say("تأكد من إدخال أرقام صحيحة.");
    const { error } = await sb.from("profiles").upsert({ ...row, user_id: session.user.id, updated_at: new Date().toISOString() });
    if (error) return say("البيانات خارج الحدود المسموحة (الطول ١٠٠–٢٥٠، الوزن ٢٥–٣٥٠).");
    tab = "today"; await load();
  };
  return h("div", { class: "card" }, h("h2", {}, "بياناتك"), Object.values(els), h("button", { onclick: save }, "حفظ"),
    h("p", { class: "mut" }, "الهدف اليومي تقدير عام وليس نصيحة طبية. استشر مختصًا عند وجود حالة صحية."));
}

function addView() {
  const type = h("select", {}, Object.entries(MEALS).map(([v, t]) => h("option", { value: v }, t)));
  const q = h("input", { placeholder: "ابحث: كبسة، فلافل، تمر…" });
  const results = h("div"); const aiOut = h("div");
  const insert = async (row) => {
    const { error } = await sb.from("meal_logs").insert({ meal_type: type.value, eaten_on: localDate(), ...row });
    if (error) return say("تعذّر حفظ الوجبة."); await load();
  };
  const pick = (food) => {
    const g = h("input", { inputmode: "decimal", value: food.default_serving_g, "aria-label": "الكمية بالغرام" });
    results.replaceChildren(h("div", { class: "card" }, h("b", {}, food.name_ar), h("div", { class: "mut" }, `الحصة المعتادة: ${food.serving_label_ar ?? ""} (${food.default_serving_g} غ)`), g,
      h("button", { onclick: () => { const grams = parseNumber(g.value); if (!(grams > 0 && grams <= 5000)) return say("الكمية يجب أن تكون بين ١ و ٥٠٠٠ غرام."); insert({ name_ar: food.name_ar, grams, source: "db", food_id: food.id, ...scaleNutrition(food, grams) }); } }, "إضافة")));
  };
  q.addEventListener("input", () => results.replaceChildren(...searchFoods(foods, q.value).map((f) => h("button", { class: "sec", onclick: () => pick(f) }, `${f.name_ar} — ${f.kcal_100g} سعرة/١٠٠غ`))));
  const desc = h("textarea", { rows: "3", maxlength: "500", placeholder: "اوصف وجبتك: مثلًا «صحن كبسة دجاج مع سلطة وكاسة لبن»" });
  const analyze = async (btn) => {
    btn.disabled = true; aiOut.replaceChildren(h("p", { class: "mut" }, "جارٍ التحليل…"));
    const { data, error } = await sb.functions.invoke("analyze-meal", { body: { description: desc.value } });
    btn.disabled = false;
    if (error) { const st = error.context?.status; return aiOut.replaceChildren(h("p", { class: "err" }, st === 429 ? "وصلت للحد الأقصى من التحليلات هذه الساعة." : st === 422 ? "لم أجد طعامًا في الوصف. جرّب صياغة أخرى." : "تعذّر التحليل الآن.")); }
    aiOut.replaceChildren(h("p", { class: "mut" }, "تقدير تقريبي بالذكاء الاصطناعي — راجع الكميات قبل الإضافة."),
      data.items.map((it) => h("div", { class: "item" }, h("span", {}, `${it.name_ar} · ${it.grams}غ · ${it.kcal} سعرة${it.inconsistent ? " ⚠︎" : ""}`),
        h("button", { class: "sec", style: "width:auto", onclick: () => insert({ name_ar: it.name_ar, grams: it.grams, kcal: it.kcal, protein_g: it.protein_g, carbs_g: it.carbs_g, fat_g: it.fat_g, source: "ai" }) }, "إضافة"))));
  };
  const aiBtn = h("button", { onclick: (e) => analyze(e.currentTarget) }, "حلّل بالذكاء الاصطناعي");
  return h("div", {}, h("div", { class: "card" }, h("h2", {}, "إضافة وجبة"), type, q, results),
    h("div", { class: "card" }, h("h2", {}, "أو اوصفها بكلماتك"), desc, aiBtn, aiOut));
}

function todayView() {
  const { target, floorApplied } = dailyTarget(profile);
  const t = sumTotals(logs); const pct = Math.min(100, Math.round((t.kcal / target) * 100));
  const groups = Object.entries(MEALS).map(([k, label]) => {
    const rows = logs.filter((l) => l.meal_type === k); if (!rows.length) return null;
    return h("div", { class: "card" }, h("h2", {}, label), rows.map((r) => h("div", { class: "item" },
      h("span", {}, `${r.name_ar} · ${r.grams}غ${r.source === "ai" ? " (تقدير)" : ""}`),
      h("span", {}, `${Math.round(r.kcal)} `, h("button", { class: "del", "aria-label": "حذف", onclick: async () => { const { error } = await sb.from("meal_logs").delete().eq("id", r.id); if (error) say("تعذّر الحذف."); else load(); } }, "✕")))));
  });
  return h("div", {}, h("div", { class: "card" }, h("div", { class: "mut" }, "المتناول اليوم"), h("div", { class: "big" }, `${Math.round(t.kcal)} / ${target}`),
    h("div", { class: `bar${t.kcal > target ? " over" : ""}` }, h("i", { style: `width:${pct}%` })),
    h("div", { class: "mut" }, `بروتين ${t.protein_g}غ · كربوهيدرات ${t.carbs_g}غ · دهون ${t.fat_g}غ`),
    floorApplied ? h("p", { class: "mut" }, "رُفع الهدف إلى الحد الأدنى الآمن. يُفضَّل استشارة مختص قبل أي حمية قاسية.") : null),
    groups, logs.length ? null : h("p", { class: "mut" }, "لم تسجّل شيئًا اليوم بعد."));
}

function render() {
  const bar = h("div", { class: "row" }, h("h1", {}, "سُعرات"), session ? h("button", { class: "sec", style: "flex:0 0 auto;width:auto", onclick: () => { foods = []; sb.auth.signOut(); } }, "خروج") : null);
  const view = tab === "add" ? addView : tab === "profile" ? profileView : todayView;
  const body = !session ? authView() : !profile ? profileView() :
    h("div", {}, h("div", { class: "tabs" }, [["today", "اليوم"], ["add", "إضافة"], ["profile", "بياناتي"]].map(([k, t]) => h("button", { class: tab === k ? "on" : "", onclick: () => { tab = k; notice = ""; render(); } }, t))), view());
  root.replaceChildren(bar, notice ? h("p", { class: "err", role: "alert" }, notice) : null, body);
}

boot();
