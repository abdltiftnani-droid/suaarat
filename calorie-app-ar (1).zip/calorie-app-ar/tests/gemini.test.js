import test from "node:test";
import assert from "node:assert/strict";
import { callGemini } from "../supabase/functions/analyze-meal/gemini.js";

const mk = (body, status = 200) => async (url, init) => { mk.last = { url, init }; return new Response(JSON.stringify(body), { status }); };
const wrap = (obj) => ({ candidates: [{ content: { parts: [{ text: JSON.stringify(obj) }] } }] });

test("sends key in header only, JSON schema mode, and parses result", async () => {
  const f = mk(wrap({ items: [] }));
  const out = await callGemini("كبسة", { apiKey: "KEY123", model: "gemini-2.5-flash", fetchImpl: f });
  assert.deepEqual(out, { items: [] });
  assert.ok(!mk.last.url.includes("KEY123")); assert.equal(mk.last.init.headers["x-goog-api-key"], "KEY123");
  const body = JSON.parse(mk.last.init.body);
  assert.equal(body.generationConfig.responseMimeType, "application/json"); assert.ok(body.generationConfig.responseSchema);
  assert.equal(body.contents[0].parts[0].text, "كبسة");
});
test("throws on missing key, HTTP error, empty candidates, invalid JSON text", async () => {
  await assert.rejects(callGemini("x", { apiKey: "", fetchImpl: mk({}) }), /missing_api_key/);
  await assert.rejects(callGemini("x", { apiKey: "k", fetchImpl: mk({}, 500) }), /gemini_http_500/);
  await assert.rejects(callGemini("x", { apiKey: "k", fetchImpl: mk({ candidates: [] }) }), /gemini_empty/);
  await assert.rejects(callGemini("x", { apiKey: "k", fetchImpl: mk({ candidates: [{ content: { parts: [{ text: "not json" }] } }] }) }));
});
