import test from "node:test";
import assert from "node:assert/strict";
import { bmr, dailyTarget, scaleNutrition, sumTotals, parseNumber, normalizeArabic, searchFoods } from "../web/calc.js";

test("bmr Mifflin-St Jeor male/female", () => {
  assert.equal(bmr({ sex: "male", weight_kg: 80, height_cm: 180, age: 30 }), 1780);
  assert.equal(bmr({ sex: "female", weight_kg: 60, height_cm: 165, age: 25 }), 1345.25);
});
test("dailyTarget applies goal and activity", () => {
  const p = { sex: "male", birth_year: 1996, weight_kg: 80, height_cm: 180, activity: "moderate", goal: "maintain" };
  const m = dailyTarget(p, 2026); assert.equal(m.tdee, Math.round(1780 * 1.55)); assert.equal(m.floorApplied, false);
  assert.ok(dailyTarget({ ...p, goal: "lose" }, 2026).target < m.target);
  assert.ok(dailyTarget({ ...p, goal: "gain" }, 2026).target > m.target);
});
test("dailyTarget never goes below the safety floor", () => {
  const p = { sex: "female", birth_year: 1966, weight_kg: 45, height_cm: 150, activity: "sedentary", goal: "lose" };
  const r = dailyTarget(p, 2026); assert.equal(r.target, 1200); assert.equal(r.floorApplied, true);
});
test("scaleNutrition scales per-100g values", () => {
  assert.deepEqual(scaleNutrition({ kcal_100g: 282, protein_100g: 2.5, carbs_100g: 75, fat_100g: 0.4 }, 200), { kcal: 564, protein_g: 5, carbs_g: 150, fat_g: 0.8 });
});
test("sumTotals", () => {
  assert.deepEqual(sumTotals([{ kcal: 100, protein_g: 1.1, carbs_g: 2, fat_g: 3 }, { kcal: "50", protein_g: 2.2, carbs_g: 1, fat_g: 0 }]), { kcal: 150, protein_g: 3.3, carbs_g: 3, fat_g: 3 });
  assert.deepEqual(sumTotals([]), { kcal: 0, protein_g: 0, carbs_g: 0, fat_g: 0 });
});
test("parseNumber handles Arabic-Indic digits and decimals, rejects junk", () => {
  assert.equal(parseNumber("١٢٥"), 125); assert.equal(parseNumber("۷۰"), 70);
  assert.equal(parseNumber("٧٢٫٥"), 72.5); assert.equal(parseNumber("72,5"), 72.5);
  for (const bad of ["", "abc", "-5", "1e3", "12 kg", null, undefined]) assert.ok(Number.isNaN(parseNumber(bad)), String(bad));
});
test("normalizeArabic unifies letter variants and strips diacritics", () => {
  assert.equal(normalizeArabic("كُبْسَة"), "كبسه"); assert.equal(normalizeArabic("أرز"), "ارز"); assert.equal(normalizeArabic("مَقلوبة"), "مقلوبه");
});
test("searchFoods is forgiving and bounded", () => {
  const foods = [{ name_ar: "كبسة دجاج", name_en: "Chicken kabsa" }, { name_ar: "كبسة لحم", name_en: "Lamb kabsa" }, { name_ar: "فلافل", name_en: "Falafel" }];
  assert.equal(searchFoods(foods, "كبسه").length, 2); assert.equal(searchFoods(foods, "KABSA").length, 2);
  assert.equal(searchFoods(foods, "").length, 0); assert.equal(searchFoods(foods, "كبسة", 1).length, 1);
});
