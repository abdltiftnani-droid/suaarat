import test from "node:test";
import assert from "node:assert/strict";
import { sanitizeAiItems, MAX_ITEMS } from "../supabase/functions/analyze-meal/nutrition.js";

const ok = { name_ar: "كبسة دجاج", grams: 350, kcal: 580, protein_g: 32, carbs_g: 74, fat_g: 18 };

test("accepts a valid item and flags nothing", () => {
  const [i] = sanitizeAiItems({ items: [ok] }); assert.equal(i.name_ar, "كبسة دجاج"); assert.equal(i.inconsistent, false);
});
test("non-array / garbage input yields empty list", () => {
  for (const x of [null, undefined, "x", 5, {}, { items: "no" }]) assert.deepEqual(sanitizeAiItems(x), []);
});
test("drops invalid items: missing name, NaN, negative, zero grams", () => {
  const bad = [{ ...ok, name_ar: "" }, { ...ok, kcal: "abc" }, { ...ok, kcal: -1 }, { ...ok, grams: 0 }, { ...ok, fat_g: undefined }, null, 7];
  assert.deepEqual(sanitizeAiItems(bad), []);
});
test("clamps absurd values instead of trusting the model", () => {
  const [i] = sanitizeAiItems([{ ...ok, grams: 99999, kcal: 999999, protein_g: 9999 }]);
  assert.equal(i.grams, 3000); assert.equal(i.kcal, 5000); assert.equal(i.protein_g, 500);
});
test("caps item count and coerces numeric strings", () => {
  assert.equal(sanitizeAiItems(Array.from({ length: 50 }, () => ok)).length, MAX_ITEMS);
  assert.equal(sanitizeAiItems([{ ...ok, grams: "200" }])[0].grams, 200);
});
test("flags kcal that contradicts macros", () => {
  assert.equal(sanitizeAiItems([{ ...ok, kcal: 2000 }])[0].inconsistent, true);
});
test("strips control characters and truncates long names", () => {
  const [i] = sanitizeAiItems([{ ...ok, name_ar: "ك\u0000ب\nسة" + "ا".repeat(300) }]);
  assert.ok(!/[\u0000-\u001f]/.test(i.name_ar)); assert.ok(i.name_ar.length <= 120);
});
